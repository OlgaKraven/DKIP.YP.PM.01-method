# Каталог и календарная цена

Открыть app/CatalogDesk.csproj в Windows с .NET SDK 10.
Заменить app/Data/catalog.json данными своей области.

dotnet build app/CatalogDesk.csproj
dotnet run --project app/CatalogDesk.csproj

Порядок работы и проверки: https://olgakraven.github.io/DKIP.YP.PM.01-method/
