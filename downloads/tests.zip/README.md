Распаковать рядом с app собственного проекта. Добавить data/vNN/catalog.json своего варианта. Выполнить из папки с app, checks и data: dotnet run --project checks/PricingChecks.csproj -- .
При ошибке сверить первое ожидалось/получено. Исправить модуль и повторить.
