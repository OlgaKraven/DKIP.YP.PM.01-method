namespace CatalogDesk;

public static class Pricing
{
    public static (DateOnly Start, DateOnly End) PreviousMonth(DateOnly asOf)
        => throw new NotImplementedException();
    public static PriceResult Calculate(decimal basePrice, string productId,
        IEnumerable<OrderLine> orders, DateOnly asOf)
        => throw new NotImplementedException();
    public static (int Total, string Label) StockSummary(IEnumerable<StockItem> stocks)
        => throw new NotImplementedException();
    public static ProductCard CreateCard(Product product, IEnumerable<OrderLine> orders, DateOnly asOf)
        => throw new NotImplementedException();
}
